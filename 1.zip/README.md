# JSON to CSV Converter

A Vue 3 + TypeScript + Vite starter for a browser-based JSON-to-CSV tool.

## Requirements
- Node.js 20.19+ or 22.12+ recommended for current Vite 6 releases.

## Run locally
```bash
npm install
npm run dev
```

## Validate the project
```bash
npm run type-check
npm test
npm run build
```

## Privacy
The conversion function runs in the browser. The starter does not send input JSON to a conversion API.

## Current conversion behavior
- Detects non-empty arrays of objects at the top level or nested in API response objects; select the array when multiple candidates are found.
- Nested objects flatten to dot-separated columns by default.
- Arrays remain JSON text inside a single CSV cell.
- Columns are collected in first-seen order; missing values become empty cells.
- CSV quoting follows common CSV escaping rules.
- Spreadsheet formula protection is a mitigation for common dangerous string prefixes, not a guarantee across every spreadsheet application.


### Column selection

After conversion, use the simple column checklist to include only the fields you need. Select or deselect all columns at once. The CSV preview and download reflect the selected columns.

## Available tools
- `/` — JSON to CSV, including array detection, nested-object flattening, formula-prefix mitigation, column selection, preview, and download.
- `/json-to-excel.html` — JSON to Excel, exporting a real `.xlsx` workbook with typed number/boolean cells, optional nested-object flattening, column selection, frozen header row, and worksheet autofilter.

The Excel workbook is generated locally with the ZIP/XML parts required by the XLSX format, so no workbook service or additional runtime package is required. Both tool pages share the same visual styles and link to one another. The sitemap includes the new page.

## Excel conversion tests
The Excel converter utility and workbook writer are in `src/utils/jsonToExcel.ts`; tests are in `src/utils/jsonToExcel.test.ts`.

## Application structure

- `src/components/JsonToCsvTool.vue` contains the standalone JSON-to-CSV tool page and its UI state.
- `src/components/JsonToExcelTool.vue` contains the standalone JSON-to-Excel tool page and its UI state.
- `src/App.vue` mounts the JSON-to-CSV tool for the main page.
- `src/main.ts` is the Vite entry point for `index.html`.
- `src/excel.ts` mounts the JSON-to-Excel tool for `json-to-excel.html`.
- `src/utils/` contains the conversion logic and its unit tests, separate from the Vue components.

Each tool has its own Vue component. The two pages continue to share the global stylesheet and selected JSON-array discovery helpers.

