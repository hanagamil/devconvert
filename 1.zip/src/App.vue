<script setup lang="ts">
import JsonToCsvTool from './components/JsonToCsvTool.vue'
</script>

<template>
  <JsonToCsvTool />
</template>
